var contentNode = document.getElementById('contents');
var component = <h1>Sup earth</h1>;
ReactDOM.render(component, contentNode); //render the component inside the contentNode